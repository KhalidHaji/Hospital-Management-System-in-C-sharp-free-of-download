﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AhsaniaHospital
{
    enum Counties
    {
        Dhaka,
        Barishal,
        Chittagong,
        Mymensingh,
        Khulna,
        Rajshahi,
        Rangpur,
        Sylhet
       

    }
    enum Specialties
    {
        Heart,
        Lungs
    }
}
