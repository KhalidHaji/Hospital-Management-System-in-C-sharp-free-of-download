﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;



[assembly: AssemblyTitle("AhsaniaHospital")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AhsaniaHospital")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(true)]

[assembly: Guid("4777795a-ab8e-4d3a-b807-767107df4614")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
